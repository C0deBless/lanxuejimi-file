/**
 * Kakao Android SDK에서 제공하는 위젯
 * <br/> 로그인 버튼, 사용자 프로필 Layout을 제공한다.
 */
package com.kakao.widget;