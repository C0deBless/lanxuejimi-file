Kakao SDK / core library / util
Kakao SDK를 사용하기 위해 기본적으로 필요한 Utility
