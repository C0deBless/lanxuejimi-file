/**
 * Kakao Android SDK
 * <br/> 사용자 관리, 카카오스토리, 카카오톡, 카카오링크 API를 제공한다.
 */
package com.kakao;