Kakao SDK / core library / login
로그인 기반으로 하는 모든 API를 사용하기 위해서 기반이 되는 모듈
설치되어 있는 카카오톡에 로그인된 계정을 이용하거나,
그렇지 않은 경우 카카오계정의 ID/PASSWORD를 받아 인증 받는다.
