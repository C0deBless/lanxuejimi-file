/** Automatically generated file. DO NOT MODIFY */
package com.tigergames.kakaoplugin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}