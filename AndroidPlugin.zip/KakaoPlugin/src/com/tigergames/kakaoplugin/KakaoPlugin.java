package com.tigergames.kakaoplugin;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;

import com.kakao.APIErrorResult;
import com.kakao.MeResponseCallback;
import com.kakao.Session;
import com.kakao.SessionCallback;
import com.kakao.UserManagement;
import com.kakao.UserProfile;
import com.kakao.exception.KakaoException;
import com.kakao.widget.LoginButton;
import com.unity3d.player.UnityPlayer;

public class KakaoPlugin {

	private LoginButton loginButton;
	private final SessionCallback mySessionCallback = new MySessionStatusCallback();
	private static final String tag = "KakaoPlugin";

	private String gameObject;
	private boolean isLoggedIn = false;
	private UserProfile userProfile;

	public void init(String gameObject) {
		Log.d(tag, "init");
		this.gameObject = gameObject;
		final Activity currentActivity = UnityPlayer.currentActivity;
		currentActivity.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				loginButton = new LoginButton(currentActivity);
				loginButton.setLoginSessionCallback(mySessionCallback);
				UnityPlayer.UnitySendMessage(KakaoPlugin.this.gameObject,
						"OnInitKakaoPlugin", "");

				if (Session.initializeSession(currentActivity,
						mySessionCallback)) {
					loginButton.setVisibility(View.GONE);
					Log.d(tag,
							"initializeSession..loginButton.setVisibility(View.GONE);");
				} else if (Session.getCurrentSession().isOpened()) {
					requestUser();
				}
			}
		});
	}

	private void requestUser() {
		UserManagement.requestMe(new MeResponseCallback() {

			@Override
			protected void onSuccess(final UserProfile userProfile) {
				Log.d(tag, "UserProfile : " + userProfile);
				userProfile.saveUserToCache();
				setLoggedIn(true);
				KakaoPlugin.this.userProfile = userProfile;
				UnityPlayer.UnitySendMessage(KakaoPlugin.this.gameObject,
						"OnKakaoLogin", "");
			}

			@Override
			protected void onNotSignedUp() {
				setLoggedIn(false);
			}

			@Override
			protected void onSessionClosedFailure(
					final APIErrorResult errorResult) {
				setLoggedIn(false);
			}

			@Override
			protected void onFailure(final APIErrorResult errorResult) {
				String message = "failed to get user info. msg=" + errorResult;
				Log.d(tag, message);
				setLoggedIn(false);
			}
		});
	}

	public void ShowLoginButton() {
		final Activity currentActivity = UnityPlayer.currentActivity;
		currentActivity.runOnUiThread(new Runnable() {
			public void run() {
				currentActivity.addContentView(loginButton,
						new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
								LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
			}
		});
	}

	public void HideLoginButton() {
		Log.d(tag, "HideLoginButton");
		final Activity currentActivity = UnityPlayer.currentActivity;
		currentActivity.runOnUiThread(new Runnable() {
			public void run() {
				loginButton.setVisibility(View.GONE);
			}
		});
	}

	private class MySessionStatusCallback implements SessionCallback {

		@Override
		public void onSessionOpened() {
			Log.d(tag, "onSessionOpened");
			KakaoPlugin.this.onSessionOpened();
		}

		@Override
		public void onSessionClosed(final KakaoException exception) {
			Log.d(tag, "onSessionClosed");
			loginButton.setVisibility(View.VISIBLE);
		}

	}

	protected void onSessionOpened() {
		final Intent intent = new Intent(UnityPlayer.currentActivity,
				KakaoSignupActivity.class);
		UnityPlayer.currentActivity.startActivity(intent);
	}

	public boolean isLoggedIn() {
		return isLoggedIn;
	}

	public void setLoggedIn(boolean isLoggedIn) {
		this.isLoggedIn = isLoggedIn;
	}
}
