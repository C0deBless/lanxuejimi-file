package chatting;

public class Command {
	public static short C_LOGIN = 1;
	public static short S_LOGIN = 2;
}
