package easysocket.session;

public enum SessionType {
	CLIENT_SESSION, DATABASE_SESSION,
}