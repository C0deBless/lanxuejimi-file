package easysocket.serialize;

public interface FixedSizeSerializable extends Serializable {
	public int getSize();
}
